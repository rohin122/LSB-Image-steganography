/*
NAME : ROHAN ARI
DESCRIPTION : LSB DIGITAL IMAGE STEGANOGRAPHY.
DATE :   /11/2024.

*/
#include<stdio.h>
#include<string.h>
#include <stdlib.h>
#include"encode.h"
#include"types.h"
#include "decode.h"

int main(int argc, char *argv[])
{
	DecodeInfo decInfo;
	if(argc<3)
	{
		printf("ERROR :Lesser number of arguments\n");
	}						
	else
	{
		//chrck if -e is passed
		if(check_operation_type(argv)==e_encode)
		{
			printf("---------------------------------------------\n");
			printf("INFO :Selected encoding\n");
			printf("---------------------------------------------\n");
		    EncodeInfo e;
			if(read_and_validate_encode_args(argv, &e)==e_success)
			{
				printf("INFO :Reading and validating the arguments is a success\n");
				printf("\n");	
				printf("-----------Encoding Started---------\n");
				if(do_encoding(&e)==e_success)
				{
					printf("---------------------------------------------\n");
					printf("INFO :Encoding is successful\n");
					printf("---------------------------------------------\n");
				}	
				else
				{
					printf("ERROR :Encoding is failed.\n");
				}
			}
			
		}
		else if(check_operation_type(argv)==e_decode)
		{
			printf("INFO :Selected decoding\n");
			if((read_and_validate_decode_args(argv, &decInfo)) == e_success)
			{
				
				printf("INFO: read and validate for decoding is success.\n");
				printf("-----------Decoding Started---------\n");
				
				if((do_decoding(argv, &decInfo)) == e_success)
				{
					printf("---------------------------------------------\n");
					printf("INFO :Decoding is successful\n");
					printf("---------------------------------------------\n");
				}
				else
				{
					printf("ERROR :Decoding is failed.\n");
				}
			}
			else
			{
					printf("ERROR :Failed to read and validate the decoding arguments\n");
			}

		}
	
		else
		{
			printf("ERROR :Invalid option.please pass\nFor encoding: ./a.out -e beautiful.bmp secret.txt[stego.bmp] \n for decoding: ./a.out -d stego.bmp[decode.t]");
		}
	}
	
	return 0;
}
OperationType check_operation_type(char *argv[])
{
	if(strcmp(argv[1],"-e")==0)
	return e_encode;
	else if(strcmp(argv[1],"-d")==0)
	return e_decode;
	else
	return e_unsupported;
}
